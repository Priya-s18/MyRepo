This repository contains a Python script that scrapes data from a website, creates a zip file of the HTML pages, and creates an Excel file with the scraped data.
Requirements

    Python 3.7 or later
    aiohttp library
    beautifulsoup4 library
    xlsxwriter library
    zipfile library

Usage

    Clone the repository using git clone https://github.com/
    Navigate to the cloned repository
    Install the required libraries using pip install -r requirements.txt
    Run the script using python main.py
    for testing Run the script using python tests.py

Script Description

The main.py script does the following:

    Scrapes data from a website using aiohttp and beautifulsoup4
    Creates a zip file of the HTML pages using zipfile
    Creates an Excel file with the scraped data using xlsxwriter

Output

The script creates two output files:

    html_files.zip: A zip file containing the HTML pages scraped from the website
    nhl_stats.xlsx: An Excel file containing the scraped data

Note

This script is designed to scrape data from a specific website and may not work with other websites. You may need to modify the script to adapt to different websites or data structures.