import aiohttp
from bs4 import BeautifulSoup
import zipfile
import xlsxwriter
from typing import List, Dict

async def scrape_page(session: aiohttp.ClientSession, page_number: int) -> str:
    async with session.get(f"https://www.scrapethissite.com/pages/forms/?page={page_number}") as response:
        return await response.text()

async def scrape_all_pages() -> List[str]:
    async with aiohttp.ClientSession() as session:
        pages = []
        for i in range(1, 25):
            pages.append(await scrape_page(session, i))
        return pages

def parse_html(html: str) -> List[Dict[str, str]]:
    soup = BeautifulSoup(html, 'html.parser')
    table = soup.find('table')
    rows = []
    for row in table.find_all('tr')[1:]:
        cols = row.find_all('td')
        rows.append({
            'Team Name': cols[0].text.strip(),
            'Year': cols[1].text.strip(),
            'Wins': cols[2].text.strip(),
            'Losses': cols[3].text.strip(),
            'OT Losses': cols[4].text.strip(),
            'Win %': cols[5].text.strip(),
            'Goals For (GF)': cols[6].text.strip(),
            'Goals Against (GA)': cols[7].text.strip(),
            '+ / -': cols[8].text.strip(),
        })
    return rows


def create_zip_file(pages: List[str]) -> None:
    with zipfile.ZipFile('html_files.zip', 'w') as zip_file:
        for i, page in enumerate(pages, start=1):
            zip_file.writestr(f'{i}.html', page)


def create_excel_file(rows: List[Dict[str, str]]) -> None:
    workbook = xlsxwriter.Workbook('nhl_stats.xlsx')
    worksheet1 = workbook.add_worksheet('NHL Stats 1990-2011')
    worksheet2 = workbook.add_worksheet('Winner and Loser per Year')

    # Write data to worksheet1
    worksheet1.write_row(0, 0, ['Team Name', 'Year', 'Wins', 'Losses','OT Losses','Win %','Goals For (GF)','Goals Against (GA)','+ / -'])
    for i, row in enumerate(rows, start=1):
        worksheet1.write_row(i, 0, list(row.values()))

    # Calculate winner and loser per year
    winner_loser_per_year = {}
    for row in rows:
        year = row['Year']
        if year not in winner_loser_per_year:
            winner_loser_per_year[year] = {'winner': row['Team Name'], 'winner_wins': int(row['Wins']), 'loser': row['Team Name'], 'loser_wins': int(row['Wins'])}
        else:
            if int(row['Wins']) > winner_loser_per_year[year]['winner_wins']:
                winner_loser_per_year[year]['winner'] = row['Team Name']
                winner_loser_per_year[year]['winner_wins'] = int(row['Wins'])
            elif int(row['Wins']) < winner_loser_per_year[year]['loser_wins']:
                winner_loser_per_year[year]['loser'] = row['Team Name']
                winner_loser_per_year[year]['loser_wins'] = int(row['Wins'])

    # Write data to worksheet2
    worksheet2.write_row(0, 0, ['Year', 'Winner', 'Winner Num. of Wins', 'Loser', 'Loser Num. of Wins'])
    for i, (year, data) in enumerate(winner_loser_per_year.items(), start=1):
        worksheet2.write_row(i, 0, [year, data['winner'], data['winner_wins'], data['loser'], data['loser_wins']])

    workbook.close()


async def main() -> None:
    pages = await scrape_all_pages()
    rows = [row for page in pages for row in parse_html(page)]
    create_zip_file(pages)
    create_excel_file(rows)

if __name__ == '__main__':
    import asyncio
    asyncio.run(main())