from django.test import TestCase

import pytest
from main import parse_html, create_excel_file

@pytest.fixture
def html():
    return """
    <table>
        <tr>
            <th>Team Name</th>
            <th>Year</th>
            <th>Wins</th>
            <th>Losses</th>
            <th>OT Losses</th>
            <th>Win %</th>
            <th>Goals For (GF)</th>
            <th>Goals Against (GA)</th>
            <th>+ / -</th>
        </tr>
        <tr>
            <td>Team A</td>
            <td>1990</td>
            <td>10</td>
            <td>5</td>
            <td>2</td>
            <td>0.5</td>
            <td>100</td>
            <td>80</td>
            <td>+20</td>
        </tr>
        <tr>
            <td>Team B</td>
            <td>1990</td>
            <td>8</td>
            <td>7</td>
            <td>1</td>
            <td>0.4</td>
            <td>90</td>
            <td>100</td>
            <td>-10</td>
        </tr>
    </table>
     """


def test_parse_html(html):
    rows = parse_html(html)
    assert len(rows) == 2
    assert rows[0]['Team Name'] == 'Team A'
    assert rows[0]['Year'] == '1990'
    assert rows[0]['Wins'] == '10'
    assert rows[0]['Losses'] == '5'
    # assert rows[0]['OT Losses'] == '2'
    # assert rows[0]['Win %'] == '0.5'
    # assert rows[0]['Goals For (GF)'] == '100'
    # assert rows[0]['Goals Against (GA)'] == '80'
    # assert rows[0]['+ / -'] == '+20'


def test_create_excel_file(tmp_path):
    rows = [

        {'Team Name': 'Team A', 'Year': '1990', 'Wins': '10', 'Losses': '5', 'OT Losses': '2', 'Win %': '0.5',
         'Goals For (GF)': '100', 'Goals Against (GA)': '80', '+ / -': '+20'},
        {'Team Name': 'Team B', 'Year': '1990', 'Wins': '8', 'Losses': '7', 'OT Losses': '1', 'Win %': '0.4',
         'Goals For (GF)': '90', 'Goals Against (GA)': '100', '+ / -': '-10'},

    ]
    create_excel_file(rows)
    assert (tmp_path / 'nhl_stats.xlsx').exists()


def test_winner_loser_per_year():
    rows = [{'Team Name': 'Team A', 'Year': '1990', 'Wins': '10', 'Losses': '5'},
            {'Team Name': 'Team B', 'Year': '1990', 'Wins': '8', 'Losses': '7'},
            {'Team Name': 'Team C', 'Year': '1991', 'Wins': '12', 'Losses': '3'},
            {'Team Name': 'Team D', 'Year': '1991', 'Wins': '9', 'Losses': '6'}]
    winner_loser_per_year = {}
    for row in rows:
        year = row['Year']
        if year not in winner_loser_per_year:
            winner_loser_per_year[year] = {'winner': row['Team Name'], 'winner_wins': int(row['Wins']), 'loser': row['Team Name'], 'loser_wins': int(row['Wins'])}
        else:
            if int(row['Wins']) > winner_loser_per_year[year]['winner_wins']:
                winner_loser_per_year[year]['winner'] = row['Team Name']
                winner_loser_per_year[year]['winner_wins'] = int(row['Wins'])
            elif int(row['Wins']) < winner_loser_per_year[year]['loser_wins']:
                winner_loser_per_year[year]['loser'] = row['Team Name']
                winner_loser_per_year[year]['loser_wins'] = int(row['Wins'])
    assert winner_loser_per_year == {'1990': {'winner': 'Team A', 'winner_wins': 10, 'loser': 'Team B', 'loser_wins': 8},
                                     '1991': {'winner': 'Team C', 'winner_wins': 12, 'loser': 'Team D', 'loser_wins': 9}}
